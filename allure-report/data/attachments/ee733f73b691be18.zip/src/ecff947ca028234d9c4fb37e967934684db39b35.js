const { BasePage } = require('./BasePage');

class HomePage extends BasePage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    super(page);
    this.successMessage = page.getByText('Login Successful');
    this.logoutButton = page.locator('button:has-text("Logout")');
    this.basicElementsCard = page.locator('h1', { hasText: 'Basic Elements' });
    this.formsCard = page.locator('h1', { hasText: 'Forms' });
    // Other cards can be added similarly
  }

  async isLoginSuccessful() {
    return await this.isElementVisible(this.successMessage);
  }

  async logout() {
    await this.clickElement(this.logoutButton.first());
    await this.page.waitForNavigation();
  }

  async navigateToBasicElements() {
    await this.clickElement(this.basicElementsCard);
  }
}

module.exports = { HomePage };
