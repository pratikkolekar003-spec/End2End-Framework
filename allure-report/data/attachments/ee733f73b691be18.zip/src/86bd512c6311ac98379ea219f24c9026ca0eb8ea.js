const { BasePage } = require('./BasePage');

class LoginPage extends BasePage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    super(page);
    this.usernameInput = page.locator('#username');
    this.passwordInput = page.locator('#password');
    this.adminRadio = page.locator('#admin');
    this.userRadio = page.locator('#user');
    this.termsCheckbox = page.locator('#terms');
    this.signInButton = page.locator('button[type="submit"]');
    this.errorMessage = page.locator('p.text-\\[red\\]');
  }

  async navigateToLogin() {
    await this.navigate('/');
  }

  async login(username, password, asAdmin = true, acceptTerms = true) {
    await this.fillInput(this.usernameInput, username);
    await this.fillInput(this.passwordInput, password);
    
    if (asAdmin) {
      await this.clickElement(this.adminRadio);
    } else {
      await this.clickElement(this.userRadio);
    }

    if (acceptTerms) {
      await this.termsCheckbox.check();
    }

    await this.clickElement(this.signInButton);
  }
}

module.exports = { LoginPage };
