const { test, expect } = require('../../fixtures/testBase');
const { JSONReader } = require('../../utils/jsonReader');

const loginData = JSONReader.readData('loginData.json');

test.describe('Login Functionality - Data Driven', () => {
  for (const data of loginData) {
    test(`Login Test: ${data.testCase}`, async ({ loginPage, homePage }) => {
      await loginPage.navigateToLogin();
      
      // Perform login
      await loginPage.login(data.username, data.password, data.asAdmin, data.acceptTerms);

      if (data.expectedSuccess) {
        // Assert successful login by checking success message or URL
        const isSuccessVisible = await homePage.isLoginSuccessful();
        expect(isSuccessVisible).toBeTruthy();
        
        // Wait for URL to change to home
        await homePage.page.waitForURL(/.*home.*/);
        expect(homePage.page.url()).toContain('/home');
      } else {
        // If it's an invalid login, maybe an error message is displayed
        // Wait for potential error message or check if still on login page
        expect(loginPage.page.url()).not.toContain('/home');
      }
    });
  }
});
